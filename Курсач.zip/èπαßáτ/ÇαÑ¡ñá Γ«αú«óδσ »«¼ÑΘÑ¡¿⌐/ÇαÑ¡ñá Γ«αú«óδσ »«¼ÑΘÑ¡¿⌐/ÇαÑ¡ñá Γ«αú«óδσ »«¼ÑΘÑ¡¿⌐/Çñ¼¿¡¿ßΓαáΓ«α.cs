﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;
using System.Diagnostics.Eventing.Reader;
using Microsoft.Office.Interop.Word;
using Word = Microsoft.Office.Interop.Word;
using System.Windows.Forms.VisualStyles;

namespace Аренда_торговых_помещений
{
    public partial class Администратор : Form
    {
        DataBase database = new DataBase();
        public Администратор()
        {
            InitializeComponent();
        }
        bool flagP = false;
        bool flagK = false;
        bool flagA = false;
        bool flagPl = false;
        bool flagD = false;
        bool flagC = false;
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
        

        private void Администратор_Load(object sender, EventArgs e)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand("select [ID помещения],[Тип помещения] from Помещения ", database.getConnection());
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                comboBox4.Items.Add(reader["ID помещения"].ToString() + "-" + reader["Тип помещения"].ToString());
            }
            reader.Close();
            SqlCommand command2 = new SqlCommand("select [ИНН организации],[Название организации] from Арендаторы ", database.getConnection());
            SqlDataReader reader2 = command2.ExecuteReader();
            while (reader2.Read())
            {
                comboBox5.Items.Add(reader2["ИНН организации"].ToString() + "-" + reader2["Название организации"].ToString());
            }
            reader2.Close();
            SqlCommand command3 = new SqlCommand("DECLARE @dt datetimeoffset = switchoffset (CONVERT(datetimeoffset, GETDATE()), '-04:00'); select Аренда.[ID аренды],  Аренда.[ID помещения], Арендаторы.[Название организации] from  Аренда join Арендаторы on Арендаторы.[ИНН организации] = Аренда.[ИНН организации] where @dt < Аренда.[Дата окончания аренды] OPTION(RECOMPILE); ", database.getConnection());
            SqlDataReader reader3 = command3.ExecuteReader();
            while (reader3.Read())
            {
                comboBox7.Items.Add(reader3["ID аренды"].ToString() + "-" + reader3["ID помещения"].ToString() + " " + reader3["Название организации"].ToString());
            }
            reader3.Close();
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $" DECLARE @dt datetimeoffset = switchoffset (CONVERT(datetimeoffset, GETDATE()), '-04:00'); SELECT Помещения.[ID помещения],[Площадь помещения], Этаж, [Тип помещения], [Стоимость аренды], [Дополнительные характеристики] from Помещения join Аренда on Помещения.[ID помещения] = Аренда.[ID помещения] WHERE @dt > Аренда.[Дата окончания аренды] OPTION(RECOMPILE); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView2.DataSource = table1;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            flagA = false;
            flagD = false;
            flagK = false;
            flagP = false;
            flagPl = false;
            flagC = false;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(6, 63);
            dataGridView1.Size = new Size(1046, 463);
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            tabControl1.Visible = true;
            dataGridView1.Visible = false;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"DECLARE @dt datetimeoffset = switchoffset (CONVERT(datetimeoffset, GETDATE()), '-04:00'); SELECT Помещения.[ID помещения],[Площадь помещения], Этаж, [Тип помещения], [Стоимость аренды], [Дополнительные характеристики], [Дата начала аренды], [Дата окончания аренды] from Помещения join Аренда on Помещения.[ID помещения] = Аренда.[ID помещения] WHERE @dt > Аренда.[Дата окончания аренды] OPTION(RECOMPILE); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView2.DataSource = table1;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(6, 63);
            dataGridView1.Size = new Size(1046, 463);
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            flagP = true;
            flagK = false;
            flagA = false;
            flagPl = false;
            flagD = false;
            flagC = false;
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select * from Помещения";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(6, 63);
            dataGridView1.Size = new Size(1046, 463);
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            flagP = false;
            flagK = true;
            flagA = false;
            flagPl = false;
            flagD = false;
            flagC = false;
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select [ИНН организации], [Название организации],[Фамилия директора],  [Имя директора],  [Отчество директора],[Номер телефона], Почта, Адрес ,[Тип бизнеса], [Статус арендатора]  from Арендаторы";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(6, 63);
            dataGridView1.Size = new Size(1046, 463);
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            flagP = false;
            flagK = false;
            flagA = true;
            flagPl = false;
            flagD = false;
            flagC = false;
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT Аренда.[ID аренды], Аренда.[ID помещения], Аренда.[ИНН организации],Арендаторы.[Название организации], Аренда.[Дата начала аренды], Аренда.[Дата окончания аренды] FROM Аренда JOIN Арендаторы ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации];";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(6, 63);
            dataGridView1.Size = new Size(1046, 463);
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            flagP = false;
            flagK = false;
            flagA = false;
            flagPl = true;
            flagD = false;
            flagC = false;
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select Платежи.[ID платежа],Аренда.[ID аренды], Аренда.[ID помещения], Арендаторы.[Название организации], Платежи.[Сумма платежа], Платежи.[Дата платежа], Платежи.[Статус платежа] from Платежи join Аренда join Арендаторы on Арендаторы.[ИНН организации] = Аренда.[ИНН организации] on Платежи.[ID аренды] = Аренда.[ID аренды]";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            flagP = false;
            flagK = false;
            flagA = false;
            flagPl = false;
            flagD = false;
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT * FROM Помещения WHERE NOT EXISTS (SELECT * FROM Аренда WHERE Помещения.[ID помещения] = Аренда.[ID помещения]); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView3.DataSource = table1;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            flagP = false;
            flagK = false;
            flagA = false;
            flagPl = false;
            flagD = false;
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $" DECLARE @dt datetimeoffset = switchoffset (CONVERT(datetimeoffset, GETDATE()), '-04:00'); SELECT Помещения.[ID помещения],[Площадь помещения], Этаж, [Тип помещения], [Стоимость аренды], [Дополнительные характеристики] from Помещения join Аренда on Помещения.[ID помещения] = Аренда.[ID помещения] WHERE @dt > Аренда.[Дата окончания аренды] OPTION(RECOMPILE); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView2.DataSource = table1;
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            flagP = false;
            flagK = false;
            flagA = false;
            flagPl = false;
            flagD = false;
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT * FROM Помещения WHERE NOT EXISTS (SELECT * FROM Аренда WHERE Помещения.[ID помещения] = Аренда.[ID помещения]); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView3.DataSource = table1;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                System.Windows.Forms.ToolTip t = new System.Windows.Forms.ToolTip();
                t.SetToolTip(pictureBox3, "Добавить данные");
            }
            catch { }
        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                System.Windows.Forms.ToolTip t = new System.Windows.Forms.ToolTip();
                t.SetToolTip(pictureBox4, "Изменить данные");
            }
            catch { }
        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                System.Windows.Forms.ToolTip t = new System.Windows.Forms.ToolTip();
                t.SetToolTip(pictureBox5, "Удалить данные");
            }
            catch { }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (flagP == true)
            {
                panel2.Visible = true;
                label2.Text = "Новое помещение";
                
            }
            
            else if(flagK == true)
            {
                panel3.Visible = true;
                label8.Location = new System.Drawing.Point(181, 11);
                label8.Text = "Новый арендатор";
                
            }
            else if(flagA == true)
            {
                panel1.Visible = true;
                label24.Text = "Новая аренда";
            }
            else if(flagPl == true)
            {
                panel4.Visible = true;
                label28.Text = "Новый платеж";
            }
            else if (flagC == true)
            {
                panel6.Visible = true;
                label48.Text = "Новый сотрудник";
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (flagP == true)
            {
                panel2.Visible = true;
                label2.Text = "Изменение данных о помещении";
            }
            else if (flagK == true)
            {
                panel3.Visible = true;
                label8.Text = "Изменение данных об арендаторе";
            }
            else if (flagA == true)
            {
                panel1.Visible = true;
                label24.Text = "Изменение данных об аренде";
            }
            else if (flagPl == true)
            {
                panel4.Visible = true;
                label28.Text = "Изменение данных о платеже";
            }
            else if (flagC == true)
            {
                panel6.Visible = true;
                label48.Text = "Изменение данных о сотруднике";
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (flagP == true)
            {
                label2.Location = new System.Drawing.Point(66, 15);
                label2.Text = "Изменение данных о помещении";
                textBox5.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                comboBox1.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            }
            else if (flagK == true)
            {
                label8.Location = new System.Drawing.Point(40, 13);
                label8.Text = "Изменение данных об арендаторе";
                textBox6.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                textBox7.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox8.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                textBox9.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                textBox10.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                textBox11.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                textBox12.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                textBox13.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                comboBox2.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
                comboBox3.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            }    
            else if (flagA == true)
            {
                label24.Location = new System.Drawing.Point(119, 15);
                label24.Text = "Изменение данных об аренде";
                textBox14.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                comboBox4.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                comboBox5.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                dateTimePicker1.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                dateTimePicker2.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            }
            else if(flagPl == true)
            {
                label28.Location = new System.Drawing.Point(83, 15);
                label28.Text = "Изменение данных о платеже";
                textBox15.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                comboBox7.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox16.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                dateTimePicker4.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                comboBox6.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            }
            else if (flagD == true)
            {
                organtb.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                FIOtb.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                adrestb.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                etaghtb.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                idpomechtb.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                plostb.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                summatb.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                naghDate.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                konhDate.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            }
            else if (flagC == true)
            {
                label48.Text = "Изменение данных о сотруднике";
                textBox25.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                textBox24.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox23.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                textBox23.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                textBox21.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                textBox20.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                textBox19.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                comboBox9.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                textBox17.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
                textBox18.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            }
        }
        
        

        private void button7_Click(object sender, EventArgs e)
        {
            if (label2.Text == "Новое помещение")
            {
                database.openConnection();
                if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox3.Text == ""  && comboBox1.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Insert into [Помещения]([Площадь помещения], [Этаж], [Тип помещения], [Стоимость аренды], [Дополнительные характеристики]) VALUES (@a, @b, @c, @d,@e)";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("a", textBox1.Text);
                    command.Parameters.AddWithValue("b", textBox2.Text);
                    command.Parameters.AddWithValue("c", comboBox1.Text);
                    command.Parameters.AddWithValue("d", textBox3.Text);
                    command.Parameters.AddWithValue("e", textBox4.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel2.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select * from Помещения";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    comboBox1.Text = "";
                }
            }
            else if (label2.Text == "Изменение данных о помещении")
            {
                database.openConnection();

                if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox3.Text == ""  && comboBox1.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Update [Помещения] set [Площадь помещения]=@a, [Этаж]=@b, [Тип помещения]=@c, [Стоимость аренды]=@d, [Дополнительные характеристики]=@e  Where [ID помещения] = @cl";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("cl", textBox5.Text);
                    command.Parameters.AddWithValue("a", textBox1.Text);
                    command.Parameters.AddWithValue("b", textBox2.Text);
                    command.Parameters.AddWithValue("c", comboBox1.Text);
                    command.Parameters.AddWithValue("d", textBox3.Text);
                    command.Parameters.AddWithValue("e", textBox4.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно изменена");
                    database.closeConnection();
                    panel2.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select * from Помещения";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    comboBox1.Text = "";
                    textBox5.Text = "";
                }
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "";
            textBox13.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            flagD = true;
            flagA = false;
            flagK = false;
            flagP = false;
            flagPl = false;
            flagC = false;
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = true;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(0, 20);
            dataGridView1.Size = new Size(607, 509);
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT [Название организации],Concat([Фамилия директора], ' ', [Имя директора] , ' ', [Отчество директора]) as Директор, Адрес, Этаж, Помещения.[ID помещения], [Площадь помещения], [Стоимость аренды], [Дата начала аренды], [Дата окончания аренды] FROM   Арендаторы JOIN  Аренда  ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации] JOIN  Помещения  ON Аренда.[ID помещения] = Помещения.[ID помещения];";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;

        }

        private void button8_Click(object sender, EventArgs e)
        {

            if (label8.Text == "Новый арендатор")
            {
                database.openConnection();
                if (textBox6.Text == "" && textBox7.Text == "" && textBox8.Text == "" && textBox9.Text == "" && textBox10.Text == "" && textBox11.Text == "" && textBox12.Text == "" && textBox13.Text == "" && comboBox2.Text == "" && comboBox3.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Insert into [Арендаторы]([ИНН организации], [Название организации], [Фамилия директора], [Имя директора], [Отчество директора], [Номер телефона], [Почта], [Адрес],[Тип бизнеса],[Статус арендатора]) VALUES (@q,@w,@e,@r,@t,@y,@u,@i,@o,@p)";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", textBox6.Text);
                    command.Parameters.AddWithValue("w", textBox7.Text);
                    command.Parameters.AddWithValue("e", textBox8.Text);
                    command.Parameters.AddWithValue("r", textBox9.Text);
                    command.Parameters.AddWithValue("t", textBox10.Text);
                    command.Parameters.AddWithValue("y", textBox11.Text);
                    command.Parameters.AddWithValue("u", textBox12.Text);
                    command.Parameters.AddWithValue("i", textBox13.Text);
                    command.Parameters.AddWithValue("o", comboBox2.Text);
                    command.Parameters.AddWithValue("p", comboBox3.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel3.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select [ИНН организации], [Название организации],[Фамилия директора],  [Имя директора],  [Отчество директора],[Номер телефона], Почта, Адрес ,[Тип бизнеса], [Статус арендатора]  from Арендаторы";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    textBox9.Text = "";
                    textBox10.Text = "";
                    textBox11.Text = "";
                    textBox12.Text = "";
                    textBox13.Text = "";
                    comboBox2.Text = "";
                    comboBox3.Text = "";
                }
            }
            else if (label8.Text == "Изменение данных об арендаторе")
            {
                database.openConnection();

                if (textBox6.Text == "" && textBox7.Text == "" && textBox8.Text == "" && textBox9.Text == "" && textBox10.Text == "" && textBox11.Text == "" && textBox12.Text == "" && textBox13.Text == "" && comboBox2.Text == "" && comboBox3.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Update [Арендаторы] set [Название органзации]=@w, [Фамилия директора]=@e, [Имя директора]=@r, [Отчетсво директора]=@t, [Номер телефона]=@y, [Почта]=@u, [Адрес]=@i, [Тип бизнеса]=@o, [Статус арендатора]=@p  Where [ИНН организации] = @q";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", textBox6.Text);
                    command.Parameters.AddWithValue("w", textBox7.Text);
                    command.Parameters.AddWithValue("e", textBox8.Text);
                    command.Parameters.AddWithValue("r", textBox9.Text);
                    command.Parameters.AddWithValue("t", textBox10.Text);
                    command.Parameters.AddWithValue("y", textBox11.Text);
                    command.Parameters.AddWithValue("u", textBox12.Text);
                    command.Parameters.AddWithValue("i", textBox13.Text);
                    command.Parameters.AddWithValue("o", comboBox2.Text);
                    command.Parameters.AddWithValue("p", comboBox3.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel3.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select [ИНН организации], [Название организации],[Фамилия директора],  [Имя директора],  [Отчество директора],[Номер телефона], Почта, Адрес ,[Тип бизнеса], [Статус арендатора]  from Арендаторы";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    textBox9.Text = "";
                    textBox10.Text = "";
                    textBox11.Text = "";
                    textBox12.Text = "";
                    textBox13.Text = "";
                    comboBox2.Text = "";
                    comboBox3.Text = "";
                }
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            try
            {
                if (flagP == true)
                {
                    database.openConnection();
                    DialogResult result = MessageBox.Show("Текущая запись может быть связана с другими таблицами! Хотите продолжить?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.OK)
                    {
                        string к = @"Delete from Аренда where [ID помещения]= @cl";
                        SqlCommand command3 = new SqlCommand(к, database.getConnection());
                        command3.Parameters.AddWithValue("cl", textBox5.Text);
                        command3.ExecuteScalar();
                        database.openConnection();
                        string q = @"Delete from Помещения where [ID помещения]= @cl";
                        SqlCommand command1 = new SqlCommand(q, database.getConnection());
                        command1.Parameters.AddWithValue("cl", textBox5.Text);
                        command1.ExecuteScalar();
                        tabControl1.Visible = false;
                        dataGridView1.Visible = true;
                        SqlDataAdapter adapter1 = new SqlDataAdapter();
                        System.Data.DataTable table1 = new System.Data.DataTable();
                        string w = $"select * from Помещения";
                        SqlCommand command2 = new SqlCommand(w, database.getConnection());
                        adapter1.SelectCommand = command2;
                        adapter1.Fill(table1);
                        dataGridView1.DataSource = table1;
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка удаления!!!");
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

            if (label24.Text == "Новая аренда")
            {
                database.openConnection();
                if (comboBox4.Text == "" && comboBox5.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Insert into [Аренда]([ID помещения], [ИНН организации], [Дата начала аренды], [Дата окончания аренды]) VALUES (@q,@w,@e,@r)";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", comboBox4.Text.Substring(0, comboBox4.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("w", comboBox5.Text.Substring(0, comboBox5.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("e", dateTimePicker1.Text);
                    command.Parameters.AddWithValue("r", dateTimePicker2.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel1.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"SELECT Аренда.[ID аренды], Аренда.[ID помещения], Аренда.[ИНН организации],Арендаторы.[Название организации], Аренда.[Дата начала аренды], Аренда.[Дата окончания аренды] FROM Аренда JOIN Арендаторы ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации];";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    comboBox5.Text = "";
                    comboBox4.Text = "";
                }
            }
            else if (label24.Text == "Изменение данных об аренде")
            {
                database.openConnection();

                if (comboBox4.Text == "" && comboBox5.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Update [Аренда] set [ID помещения]=@w, [ИНН организации]=@e, [Дата начала аренды]=@r, [Дата окончания аренды]=@t Where [ID аренды] = @q";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", textBox14.Text);
                    command.Parameters.AddWithValue("w", comboBox4.Text.Substring(0, comboBox4.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("e", comboBox5.Text.Substring(0, comboBox5.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("r", dateTimePicker1.Text);
                    command.Parameters.AddWithValue("t", dateTimePicker2.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel1.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"SELECT Аренда.[ID аренды], Аренда.[ID помещения], Аренда.[ИНН организации],Арендаторы.[Название организации], Аренда.[Дата начала аренды], Аренда.[Дата окончания аренды] FROM Аренда JOIN Арендаторы ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации];";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    comboBox5.Text = "";
                    comboBox4.Text = "";
                }
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (label28.Text == "Новый платеж")
            {
                database.openConnection();
                if (comboBox7.Text == "" && comboBox6.Text == "" && textBox16.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Insert into [Платежи]([ID аренды], [Сумма платежа], [Дата платежа], [Статус платежа]) VALUES (@q,@w,@e,@r)";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", comboBox7.Text.Substring(0, comboBox7.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("w", textBox16.Text);
                    command.Parameters.AddWithValue("e", dateTimePicker4.Text);
                    command.Parameters.AddWithValue("r", comboBox6.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel4.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select Платежи.[ID платежа],Аренда.[ID аренды], Аренда.[ID помещения], Арендаторы.[Название организации], Платежи.[Сумма платежа], Платежи.[Дата платежа], Платежи.[Статус платежа] from Платежи join Аренда join Арендаторы on Арендаторы.[ИНН организации] = Аренда.[ИНН организации] on Платежи.[ID аренды] = Аренда.[ID аренды]";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    comboBox7.Text = "";
                    comboBox6.Text = "";
                    textBox16.Text = "";
                }
            }
            else if (label28.Text == "Изменение данных о платеже")
            {
                database.openConnection();
                if (comboBox7.Text == "" && comboBox6.Text == "" && textBox16.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Update [Платежи] set [ID аренды]=@w, [Сумма платежа]=@e, [Дата платежа]=@r, [Статус платежа]=@t Where [ID аренды] = @cl";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("cl", textBox15.Text);
                    command.Parameters.AddWithValue("q", comboBox7.Text.Substring(0, comboBox7.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("w", textBox16.Text);
                    command.Parameters.AddWithValue("e", dateTimePicker4.Text);
                    command.Parameters.AddWithValue("r", comboBox6.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel4.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select Платежи.[ID платежа],Аренда.[ID аренды], Аренда.[ID помещения], Арендаторы.[Название организации], Платежи.[Сумма платежа], Платежи.[Дата платежа], Платежи.[Статус платежа] from Платежи join Аренда join Арендаторы on Арендаторы.[ИНН организации] = Аренда.[ИНН организации] on Платежи.[ID аренды] = Аренда.[ID аренды]";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    comboBox7.Text = "";
                    comboBox6.Text = "";
                    textBox16.Text = "";
                }
            }
        }
        private readonly string TemplaterFileName = @"\\apetfs\ИСПП-3\Какиен_КВ\Курсовая МДК 02.01\Договор аренды.docx";
        private void button11_Click(object sender, EventArgs e)
        {
            var Organ = organtb.Text;
            var organ = organtb.Text;
            var FIO = FIOtb.Text;
            var fio = FIOtb.Text;
            var adres = adrestb.Text;
            var etagh = etaghtb.Text;
            var idpomech = idpomechtb.Text;
            var plos = plostb.Text;
            var summa = summatb.Text;
            var Naghdate = naghDate.Value.ToShortDateString();
            var naghdate = naghDate.Value.ToShortDateString();
            var konhdate = konhDate.Value.ToShortDateString();

            try
            {
                var wordApp = new Word.Application();
                wordApp.Visible = false;


                var wordDocument = wordApp.Documents.Open(TemplaterFileName);

                ReplaceWordstub("{organ}", organ, wordDocument);
                ReplaceWordstub("{Organ}", Organ, wordDocument);
                ReplaceWordstub("{FIO}", FIO, wordDocument);
                ReplaceWordstub("{fio}", fio, wordDocument);
                ReplaceWordstub("{adres}", adres, wordDocument);
                ReplaceWordstub("{etagh}", etagh, wordDocument);
                ReplaceWordstub("{idpomech}", idpomech, wordDocument);
                ReplaceWordstub("{plos}", plos, wordDocument);
                ReplaceWordstub("{summa}", summa, wordDocument);
                ReplaceWordstub("{naghdate}", naghdate, wordDocument);
                ReplaceWordstub("{Naghdate}", Naghdate, wordDocument);
                ReplaceWordstub("{konhdate}", konhdate, wordDocument);

                wordDocument.SaveAs(@"\\apetfs\ИСПП-3\Какиен_КВ\Курсовая МДК 02.01\Договора\Договор аренды.docx");
                wordApp.Visible = true;

            }
            catch 
            {
                MessageBox.Show("Произошла ошибка");
            }
        }

        private void ReplaceWordstub(string stubToReplace, string text,  Word.Document wordDocument)
        {
            var range = wordDocument.Content;
            range.Find.ClearFormatting();
            range.Find.Execute(FindText: stubToReplace, ReplaceWith: text);

        }

        private void button12_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(6, 63);
            dataGridView1.Size = new Size(1046, 463);
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel5.Visible = false;
            flagP = false;
            flagK = false;
            flagA = false;
            flagPl = false;
            flagD = false;
            flagC = true;
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select * from Сотрудники";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void label48_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (label48.Text == "Новый сотрудник")
            {
                database.openConnection();
                if (textBox24.Text == "" && textBox17.Text == "" && textBox18.Text == "" && textBox19.Text == "" && textBox20.Text == "" && textBox21.Text == "" && textBox22.Text == "" && textBox23.Text == "" && comboBox9.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Insert into [Сотрудники]([Фамилия], [Имя], [Отчество], [Номер телефона], [Адрес], [Почта], [Должность], [Логин],[Пароль]) VALUES (@q,@w,@e,@r,@t,@y,@u,@i,@o)";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", textBox24.Text);
                    command.Parameters.AddWithValue("w", textBox23.Text);
                    command.Parameters.AddWithValue("e", textBox22.Text);
                    command.Parameters.AddWithValue("r", textBox21.Text);
                    command.Parameters.AddWithValue("t", textBox20.Text);
                    command.Parameters.AddWithValue("y", textBox19.Text);
                    command.Parameters.AddWithValue("u", comboBox9.Text);
                    command.Parameters.AddWithValue("i", textBox17.Text);
                    command.Parameters.AddWithValue("o", textBox18.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel6.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select * from Сотрудники";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    textBox17.Text = "";
                    textBox18.Text = "";
                    textBox18.Text = "";
                    textBox20.Text = "";
                    textBox21.Text = "";
                    textBox22.Text = "";
                    textBox23.Text = "";
                    textBox24.Text = "";
                    comboBox9.Text = "";
                }
            }
            else if (label48.Text == "Изменение данных о сотруднике")
            {
                database.openConnection();

                if (textBox24.Text == "" && textBox17.Text == "" && textBox18.Text == "" && textBox19.Text == "" && textBox20.Text == "" && textBox21.Text == "" && textBox22.Text == "" && textBox23.Text == "" && comboBox9.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Update [Сотрудники] set [Фамилия]=@w, [Имя]=@e, [Отчество]=@r, [Номер телефона]=@t, [Адрес]=@y, [Почта]=@u, [Должность]=@i, [Логин]=@o, [Пароль]=@p  Where [ID сотрудника] = @q";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", textBox25.Text);
                    command.Parameters.AddWithValue("w", textBox24.Text);
                    command.Parameters.AddWithValue("e", textBox23.Text);
                    command.Parameters.AddWithValue("r", textBox22.Text);
                    command.Parameters.AddWithValue("t", textBox21.Text);
                    command.Parameters.AddWithValue("y", textBox20.Text);
                    command.Parameters.AddWithValue("u", textBox19.Text);
                    command.Parameters.AddWithValue("i", comboBox9.Text);
                    command.Parameters.AddWithValue("o", textBox17.Text);
                    command.Parameters.AddWithValue("p", textBox18.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel6.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"select * from Сотрудники";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    textBox17.Text = "";
                    textBox18.Text = "";
                    textBox18.Text = "";
                    textBox20.Text = "";
                    textBox21.Text = "";
                    textBox22.Text = "";
                    textBox23.Text = "";
                    textBox24.Text = "";
                    comboBox9.Text = "";
                }
            }
        }
    }
}

