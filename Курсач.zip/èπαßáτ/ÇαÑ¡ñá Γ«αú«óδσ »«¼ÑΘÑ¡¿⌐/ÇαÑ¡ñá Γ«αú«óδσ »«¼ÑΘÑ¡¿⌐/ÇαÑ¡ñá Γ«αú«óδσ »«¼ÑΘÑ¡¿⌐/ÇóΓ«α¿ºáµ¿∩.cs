﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Аренда_торговых_помещений
{
    public partial class Авторизация : Form
    {
        DataBase database = new DataBase();
        public Авторизация()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var login = textBox_login.Text;
            var password = textBox_pass.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string querystring = $"Select Должность, Логин, Пароль from Сотрудники where Логин='{login}' and Пароль='{password}'";

            SqlCommand command = new SqlCommand(querystring, database.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);
            if (textBox_login.Text == "" && textBox_pass.Text == "")
            {
                MessageBox.Show("Введите логин и пароль", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (table.Rows.Count >= 1)
                {
                    if (table.Rows[0]["Должность"].ToString() == "Администратор")
                    {
                        Администратор a = new Администратор();
                        this.Hide();
                        a.Show();
                    }
                    if (table.Rows[0]["Должность"].ToString() == "Делопроизводитель")
                    {
                        Делопроизводитель a = new Делопроизводитель();
                        this.Hide();
                        a.Show();
                    }
                    if (table.Rows[0]["Должность"].ToString() == "Бухгалтер")
                    {
                        Бухгалтер a = new Бухгалтер();
                        this.Hide();
                        a.Show();
                    }
                }
                else
                {
                    MessageBox.Show("Логин или пароль введён неверно!", "Неверно введены данные!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
