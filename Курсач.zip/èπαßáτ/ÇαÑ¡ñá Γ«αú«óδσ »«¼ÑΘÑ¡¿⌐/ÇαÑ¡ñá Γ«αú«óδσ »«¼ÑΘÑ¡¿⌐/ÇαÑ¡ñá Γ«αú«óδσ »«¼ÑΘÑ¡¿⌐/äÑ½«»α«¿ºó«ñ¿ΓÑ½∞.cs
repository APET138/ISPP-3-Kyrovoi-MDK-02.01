﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Word;
using Word = Microsoft.Office.Interop.Word;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace Аренда_торговых_помещений
{
    public partial class Делопроизводитель : Form
    {

        DataBase database = new DataBase();
        public Делопроизводитель()
        {
            InitializeComponent();
        }
        bool flagD = false;
        bool flagA  = false;
        private void button6_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            flagD = false;
            panel5.Visible = false;
            panel1.Visible = false;
            dataGridView1.Location = new System.Drawing.Point(6, 17);
            dataGridView1.Size = new Size(1046, 509);
            tabControl1.Visible = true;
            dataGridView1.Visible = false;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"DECLARE @dt datetimeoffset = switchoffset (CONVERT(datetimeoffset, GETDATE()), '-04:00'); SELECT Помещения.[ID помещения],[Площадь помещения], Этаж, [Тип помещения], [Стоимость аренды], [Дополнительные характеристики], [Дата начала аренды], [Дата окончания аренды] from Помещения join Аренда on Помещения.[ID помещения] = Аренда.[ID помещения] WHERE @dt > Аренда.[Дата окончания аренды] OPTION(RECOMPILE); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView2.DataSource = table1;
        }

        private void Делопроизводитель_Load(object sender, EventArgs e)
        {
            database.openConnection();
            SqlCommand command = new SqlCommand("select [ID помещения],[Тип помещения] from Помещения ", database.getConnection());
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                comboBox4.Items.Add(reader["ID помещения"].ToString() + "-" + reader["Тип помещения"].ToString());
            }
            reader.Close();
            SqlCommand command2 = new SqlCommand("select [ИНН организации],[Название организации] from Арендаторы ", database.getConnection());
            SqlDataReader reader2 = command2.ExecuteReader();
            while (reader2.Read())
            {
                comboBox5.Items.Add(reader2["ИНН организации"].ToString() + "-" + reader2["Название организации"].ToString());
            }
            reader2.Close();
            panel5.Visible = false;
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $" DECLARE @dt datetimeoffset = switchoffset (CONVERT(datetimeoffset, GETDATE()), '-04:00'); SELECT Помещения.[ID помещения],[Площадь помещения], Этаж, [Тип помещения], [Стоимость аренды], [Дополнительные характеристики] from Помещения join Аренда on Помещения.[ID помещения] = Аренда.[ID помещения] WHERE @dt > Аренда.[Дата окончания аренды] OPTION(RECOMPILE); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView2.DataSource = table1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            flagA = false;
            flagD = false;
            panel5.Visible = false;
            panel1.Visible = false;
            dataGridView1.Location = new System.Drawing.Point(6, 17);
            dataGridView1.Size = new Size(1046, 509);
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select * from Помещения";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            flagA = false;
            flagD = false;
            panel5.Visible = false;
            panel1.Visible = false;
            dataGridView1.Location = new System.Drawing.Point(6, 17);
            dataGridView1.Size = new Size(1046, 509);
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select [ИНН организации], [Название организации],[Фамилия директора],  [Имя директора],  [Отчество директора],[Номер телефона], Почта, Адрес ,[Тип бизнеса], [Статус арендатора]  from Арендаторы";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            flagA = true;
            flagD = false;
            panel5.Visible = false;
            panel1.Visible = false;
            dataGridView1.Location = new System.Drawing.Point(6, 63);
            dataGridView1.Size = new Size(1046, 463);
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT Аренда.[ID аренды], Аренда.[ID помещения], Аренда.[ИНН организации],Арендаторы.[Название организации], Аренда.[Дата начала аренды], Аренда.[Дата окончания аренды] FROM Аренда JOIN Арендаторы ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации];";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            flagA = false;
            flagD = false;
            panel5.Visible = false;
            panel1.Visible = false;
            dataGridView1.Location = new System.Drawing.Point(6, 17);
            dataGridView1.Size = new Size(1046, 509);
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select Платежи.[ID платежа],Аренда.[ID аренды], Аренда.[ID помещения], Арендаторы.[Название организации], Платежи.[Сумма платежа], Платежи.[Дата платежа], Платежи.[Статус платежа] from Платежи join Аренда join Арендаторы on Арендаторы.[ИНН организации] = Аренда.[ИНН организации] on Платежи.[ID аренды] = Аренда.[ID аренды]";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            pictureBox5.Visible = false;
            flagA = false;
            flagD = true;
            panel5.Visible = true;
            panel1.Visible = false;
            tabControl1.Visible = false;
            dataGridView1.Visible = true;
            dataGridView1.Location = new System.Drawing.Point(0, 20);
            dataGridView1.Size = new Size(607, 509);
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT [Название организации],Concat([Фамилия директора], ' ', [Имя директора] , ' ', [Отчество директора]) as Директор, Адрес, Этаж, Помещения.[ID помещения], [Площадь помещения], [Стоимость аренды], [Дата начала аренды], [Дата окончания аренды] FROM   Арендаторы JOIN  Аренда  ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации] JOIN  Помещения  ON Аренда.[ID помещения] = Помещения.[ID помещения];";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT * FROM Помещения WHERE NOT EXISTS (SELECT * FROM Аренда WHERE Помещения.[ID помещения] = Аренда.[ID помещения]); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView3.DataSource = table1;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $" DECLARE @dt datetimeoffset = switchoffset (CONVERT(datetimeoffset, GETDATE()), '-04:00'); SELECT Помещения.[ID помещения],[Площадь помещения], Этаж, [Тип помещения], [Стоимость аренды], [Дополнительные характеристики] from Помещения join Аренда on Помещения.[ID помещения] = Аренда.[ID помещения] WHERE @dt > Аренда.[Дата окончания аренды] OPTION(RECOMPILE); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView2.DataSource = table1;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (flagD == true)
            {
                organtb.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                FIOtb.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                adrestb.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                etaghtb.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                idpomechtb.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                plostb.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                summatb.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
                naghDate.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
                konhDate.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            }
            if(flagA == true) 
            {
                label24.Text = "Изменение данных об аренде";
                textBox14.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                comboBox4.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                comboBox5.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                dateTimePicker1.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                dateTimePicker2.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            }
        }
        private readonly string TemplaterFileName = @"\\apetfs\ИСПП-3\Какиен_КВ\Курсовая МДК 02.01\Договор аренды.docx";
        private void button11_Click(object sender, EventArgs e)
        {
            var Organ = organtb.Text;
            var organ = organtb.Text;
            var FIO = FIOtb.Text;
            var fio = FIOtb.Text;
            var adres = adrestb.Text;
            var etagh = etaghtb.Text;
            var idpomech = idpomechtb.Text;
            var plos = plostb.Text;
            var summa = summatb.Text;
            var Naghdate = naghDate.Value.ToShortDateString();
            var naghdate = naghDate.Value.ToShortDateString();
            var konhdate = konhDate.Value.ToShortDateString();

            try
            {
                var wordApp = new Word.Application();
                wordApp.Visible = false;


                var wordDocument = wordApp.Documents.Open(TemplaterFileName);

                ReplaceWordstub("{organ}", organ, wordDocument);
                ReplaceWordstub("{Organ}", Organ, wordDocument);
                ReplaceWordstub("{FIO}", FIO, wordDocument);
                ReplaceWordstub("{fio}", fio, wordDocument);
                ReplaceWordstub("{adres}", adres, wordDocument);
                ReplaceWordstub("{etagh}", etagh, wordDocument);
                ReplaceWordstub("{idpomech}", idpomech, wordDocument);
                ReplaceWordstub("{plos}", plos, wordDocument);
                ReplaceWordstub("{summa}", summa, wordDocument);
                ReplaceWordstub("{naghdate}", naghdate, wordDocument);
                ReplaceWordstub("{Naghdate}", Naghdate, wordDocument);
                ReplaceWordstub("{konhdate}", konhdate, wordDocument);

                wordDocument.SaveAs(@"\\apetfs\ИСПП-3\Какиен_КВ\Курсовая МДК 02.01\Договора\Договор аренды.docx");
                wordApp.Visible = true;

            }
            catch
            {
                MessageBox.Show("Произошла ошибка");
            }
        }

        private void ReplaceWordstub(string stubToReplace, string text, Word.Document wordDocument)
        {
            var range = wordDocument.Content;
            range.Find.ClearFormatting();
            range.Find.Execute(FindText: stubToReplace, ReplaceWith: text);

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if(flagA == true)
            {
                label24.Text = "Новая аренда";
                panel1.Visible = true;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (label24.Text == "Новая аренда")
            {
                database.openConnection();
                if (comboBox4.Text == "" && comboBox5.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Insert into [Аренда]([ID помещения], [ИНН организации], [Дата начала аренды], [Дата окончания аренды]) VALUES (@q,@w,@e,@r)";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", comboBox4.Text.Substring(0, comboBox4.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("w", comboBox5.Text.Substring(0, comboBox5.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("e", dateTimePicker1.Text);
                    command.Parameters.AddWithValue("r", dateTimePicker2.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel1.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"SELECT Аренда.[ID аренды], Аренда.[ID помещения], Аренда.[ИНН организации],Арендаторы.[Название организации], Аренда.[Дата начала аренды], Аренда.[Дата окончания аренды] FROM Аренда JOIN Арендаторы ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации];";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    comboBox5.Text = "";
                    comboBox4.Text = "";
                }
            }
            else if (label24.Text == "Изменение данных об аренде")
            {
                database.openConnection();

                if (comboBox4.Text == "" && comboBox5.Text == "")
                {
                    MessageBox.Show("Заполните все поля");
                }
                else
                {
                    string query = "Update [Аренда] set [ID помещения]=@w, [ИНН организации]=@e, [Дата начала аренды]=@r, [Дата окончания аренды]=@t Where [ID аренды] = @q";
                    SqlCommand command = new SqlCommand(query, database.getConnection());
                    command.Parameters.AddWithValue("q", textBox14.Text);
                    command.Parameters.AddWithValue("w", comboBox4.Text.Substring(0, comboBox4.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("e", comboBox5.Text.Substring(0, comboBox5.Text.IndexOf('-')));
                    command.Parameters.AddWithValue("r", dateTimePicker1.Text);
                    command.Parameters.AddWithValue("t", dateTimePicker2.Text);
                    command.ExecuteScalar();
                    MessageBox.Show("Запись успешно добавлена");
                    database.closeConnection();
                    panel1.Visible = false;
                    SqlDataAdapter adapter1 = new SqlDataAdapter();
                    System.Data.DataTable table1 = new System.Data.DataTable();
                    string q = $"SELECT Аренда.[ID аренды], Аренда.[ID помещения], Аренда.[ИНН организации],Арендаторы.[Название организации], Аренда.[Дата начала аренды], Аренда.[Дата окончания аренды] FROM Аренда JOIN Арендаторы ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации];";
                    SqlCommand command1 = new SqlCommand(q, database.getConnection());
                    adapter1.SelectCommand = command1;
                    adapter1.Fill(table1);
                    dataGridView1.DataSource = table1;
                    comboBox5.Text = "";
                    comboBox4.Text = "";
                }
            }

            database.openConnection();
            SqlCommand command3 = new SqlCommand("select [ID помещения],[Тип помещения] from Помещения ", database.getConnection());
            SqlDataReader reader3 = command3.ExecuteReader();
            while (reader3.Read())
            {
                comboBox4.Items.Add(reader3["ID помещения"].ToString() + "-" + reader3["Тип помещения"].ToString());
            }
            reader3.Close();
            SqlCommand command4 = new SqlCommand("select [ИНН организации],[Название организации] from Арендаторы ", database.getConnection());
            SqlDataReader reader4 = command4.ExecuteReader();
            while (reader4.Read())
            {
                comboBox5.Items.Add(reader4["ИНН организации"].ToString() + "-" + reader4["Название организации"].ToString());
            }
            reader4.Close();
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            tabControl1.Visible = true;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"SELECT * FROM Помещения WHERE NOT EXISTS (SELECT * FROM Аренда WHERE Помещения.[ID помещения] = Аренда.[ID помещения]); ";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView3.DataSource = table1;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            panel1.Visible=false;
            comboBox4.Text = "";
            comboBox5.Text = "";
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            panel1.Visible=true;
            label24.Text = "Изменение данных об аренде";
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            try
            {
                if (flagA == true)
                {
                    database.openConnection();
                    DialogResult result = MessageBox.Show("Текущая запись может быть связана с другими таблицами! Хотите продолжить?", "Удаление", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (result == DialogResult.OK)
                    {
                        string z = @"Delete from Платежи where [ID аренды]= @cl";
                        SqlCommand command5 = new SqlCommand(z, database.getConnection());
                        command5.Parameters.AddWithValue("cl", textBox14.Text);
                        command5.ExecuteScalar();
                        string к = @"Delete from Аренда where [ID аренды]= @cl";
                        SqlCommand command3 = new SqlCommand(к, database.getConnection());
                        command3.Parameters.AddWithValue("cl", textBox14.Text);
                        command3.ExecuteScalar();
                        tabControl1.Visible = false;
                        dataGridView1.Visible = true;
                        SqlDataAdapter adapter1 = new SqlDataAdapter();
                        System.Data.DataTable table1 = new System.Data.DataTable();
                        string w = $"SELECT Аренда.[ID аренды], Аренда.[ID помещения], Аренда.[ИНН организации],Арендаторы.[Название организации], Аренда.[Дата начала аренды], Аренда.[Дата окончания аренды] FROM Аренда JOIN Арендаторы ON Аренда.[ИНН организации] = Арендаторы.[ИНН организации];";
                        SqlCommand command2 = new SqlCommand(w, database.getConnection());
                        adapter1.SelectCommand = command2;
                        adapter1.Fill(table1);
                        dataGridView1.DataSource = table1;
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка удаления!!!");
            }
        }
    }
 }

