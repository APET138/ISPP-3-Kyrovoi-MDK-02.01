﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Аренда_торговых_помещений
{
    public partial class Бухгалтер : Form
    {
        DataBase database = new DataBase();
        public Бухгалтер()
        {
            InitializeComponent();
        }

        private void Бухгалтер_Load(object sender, EventArgs e)
        {
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select Платежи.[ID платежа],Аренда.[ID аренды], Аренда.[ID помещения], Арендаторы.[Название организации], Платежи.[Сумма платежа], Платежи.[Дата платежа], Платежи.[Статус платежа] from Платежи join Аренда join Арендаторы on Арендаторы.[ИНН организации] = Аренда.[ИНН организации] on Платежи.[ID аренды] = Аренда.[ID аренды]";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (label2.Text == "Введите даты")
            {
                string nach = dateTimePicker1.Text;
                string kon = dateTimePicker2.Text;
                SqlDataAdapter adapter1 = new SqlDataAdapter();
                System.Data.DataTable table1 = new System.Data.DataTable();
                string q = $"SELECT [Название организации], [Сумма платежа], [Дата платежа] FROM  Арендаторы JOIN Аренда  ON Арендаторы.[ИНН организации] = Аренда.[ИНН организации] JOIN  Платежи  ON Платежи.[ID аренды] = Аренда.[ID аренды] WHERE [Дата платежа] BETWEEN '{nach}' AND '{kon}' AND Платежи.[Статус платежа] = 'Оплачено';";
                SqlCommand command1 = new SqlCommand(q, database.getConnection());
                adapter1.SelectCommand = command1;
                adapter1.Fill(table1);
                dataGridView1.DataSource = table1;
                panel1.Visible = false;
            }
            if(label2.Text == "Выберите арендатора")
            {
                var organ = comboBox1.Text;
                SqlDataAdapter adapter1 = new SqlDataAdapter();
                System.Data.DataTable table1 = new System.Data.DataTable();
                string q = $"SELECT  [Сумма платежа], [Дата платежа] FROM Арендаторы  JOIN Аренда  ON Арендаторы.[ИНН организации] = Аренда.[ИНН организации] JOIN Платежи  ON Аренда.[ID аренды] = Платежи.[ID аренды] WHERE [Название организации] = '{organ}' AND [Статус платежа]= 'Оплачено';";
                SqlCommand command1 = new SqlCommand(q, database.getConnection());
                adapter1.SelectCommand = command1;
                adapter1.Fill(table1);
                dataGridView1.DataSource = table1;
                panel1.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "Введите даты";
            label3.Visible = true;
            label4.Visible = true;
            dateTimePicker1.Visible = true;
            dateTimePicker2.Visible = true;
            panel1.Visible = true;
            comboBox1.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            database.openConnection();
            SqlCommand command = new SqlCommand("select [ИНН организации],[Название организации] from Арендаторы ", database.getConnection());
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["Название организации"].ToString());
            }
            reader.Close();

            label2.Text = "Выберите арендатора";
            label3.Visible = false;
            label4.Visible = false;
            dateTimePicker1.Visible = false;
            dateTimePicker2.Visible = false;
            panel1.Visible = true;
            comboBox1.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            SqlDataAdapter adapter1 = new SqlDataAdapter();
            System.Data.DataTable table1 = new System.Data.DataTable();
            string q = $"select  Арендаторы.[Название организации], Платежи.[Сумма платежа], Платежи.[Дата платежа] from Платежи join Аренда join Арендаторы on Арендаторы.[ИНН организации] = Аренда.[ИНН организации] on Платежи.[ID аренды] = Аренда.[ID аренды]";
            SqlCommand command1 = new SqlCommand(q, database.getConnection());
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            dataGridView1.DataSource = table1;
        }
    }
}
