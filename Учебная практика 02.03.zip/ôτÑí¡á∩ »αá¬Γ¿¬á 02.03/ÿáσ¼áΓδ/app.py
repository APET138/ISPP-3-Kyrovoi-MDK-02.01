from flask import Flask, send_file, after_this_request,render_template
from reportlab.lib.pagesizes import letter
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from zipfile import ZipFile
from reportlab.lib.pagesizes import letter
from reportlab.lib.utils import ImageReader
from pdf2image import convert_from_path
import os
app = Flask(__name__)

# Определите пути к шаблону и выходному PDF файлу
template_path = "Грамота.pdf"
output_path = "certificate.pdf"

def generate_certificate(name, place, filename):
    c = canvas.Canvas(filename, pagesize=A4)
       # Регистрируем обычный, жирный и курсивный шрифты
    pdfmetrics.registerFont(TTFont('Arial', 'Arial.ttf'))
    pdfmetrics.registerFont(TTFont('Arial-Bold', 'Arial-Bold.ttf'))
    pdfmetrics.registerFont(TTFont('Arial-Italic', 'Arial-Italic.ttf'))

    # Конвертируем PDF-шаблон в изображение
    pages = convert_from_path(template_path, 200, poppler_path=r'E:\poppler-24.02.0\Library\bin')
    background_image = ImageReader(pages[0])
    
    c.drawImage(background_image, 0, 0, width=A4[0], height=A4[1])  # Рисуем задний фон

        # Настройка шрифта и размера для "НАГРАЖДАЕТСЯ" (курсив)
    c.setFont("Arial-Italic", 22)
    c.drawCentredString(A4[0] / 2, (A4[1] - 300) - 130, "НАГРАЖДАЕТСЯ")

    # ФИО участника (жирный)
    c.setFont("Arial-Bold", 20)
    c.drawCentredString(A4[0] / 2, (A4[1] - 340) - 130, name.upper())

    # Место участника
    place_text = "ЗАНЯВШИЙ {} МЕСТО!".format(place)
    c.setFont("Arial", 18)
    c.drawCentredString(A4[0] / 2, (A4[1] - 380) - 130, place_text)

    # Добавляем новую строку ниже
    tournament_text = "В ОБЛАСТНОМ ШАХМАТНОМ ТУРНИРЕ"
    c.setFont("Arial", 16)  # Вы можете настроить размер шрифта по вашему желанию
    c.drawCentredString(A4[0] / 2, (A4[1] - 420) - 130, tournament_text)  # Сдвигаем вниз на 120 + дополнительное расстояние

    c.save()
   

participants = [
    {'reg_number': 1, 'surname': 'Иванов', 'name': 'Иван', 'patronymic': 'Иванович', 'birth_year': 1980, 'total_games': 30, 'won_games': 20, 'draw_games': 5},
    {'reg_number': 2, 'surname': 'Петров', 'name': 'Петр', 'patronymic': 'Петрович', 'birth_year': 1975, 'total_games': 25, 'won_games': 15, 'draw_games': 7},
    {'reg_number': 3, 'surname': 'Сидоров', 'name': 'Николай', 'patronymic': 'Николаевич', 'birth_year': 1985, 'total_games': 40, 'won_games': 25, 'draw_games': 10},
    {'reg_number': 4, 'surname': 'Кузнецов', 'name': 'Сергей', 'patronymic': 'Сергеевич', 'birth_year': 1990, 'total_games': 20, 'won_games': 10, 'draw_games': 5},
    {'reg_number': 5, 'surname': 'Волков', 'name': 'Алексей', 'patronymic': 'Алексеевич', 'birth_year': 1978, 'total_games': 32, 'won_games': 18, 'draw_games': 8},
    {'reg_number': 6, 'surname': 'Соловьёв', 'name': 'Дмитрий', 'patronymic': 'Дмитриевич', 'birth_year': 1982, 'total_games': 28, 'won_games': 14, 'draw_games': 7},
    {'reg_number': 7, 'surname': 'Павлов', 'name': 'Кирилл', 'patronymic': 'Андреевич', 'birth_year': 1992, 'total_games': 36, 'won_games': 21, 'draw_games': 9},
    {'reg_number': 8, 'surname': 'Смирнов', 'name': 'Андрей', 'patronymic': 'Иванович', 'birth_year': 1988, 'total_games': 22, 'won_games': 11, 'draw_games': 6},
    {'reg_number': 9, 'surname': 'Козлов', 'name': 'Максим', 'patronymic': 'Максимович', 'birth_year': 1994, 'total_games': 30, 'won_games': 19, 'draw_games': 5},
    {'reg_number': 10, 'surname': 'Васильев', 'name': 'Антон', 'patronymic': 'Антонович', 'birth_year': 1979, 'total_games': 27, 'won_games': 16, 'draw_games': 6},
    {'reg_number': 11, 'surname': 'Морозов', 'name': 'Виктор', 'patronymic': 'Викторович', 'birth_year': 1976, 'total_games': 34, 'won_games': 22, 'draw_games': 8},
    {'reg_number': 12, 'surname': 'Новиков', 'name': 'Евгений', 'patronymic': 'Александрович', 'birth_year': 1983, 'total_games': 21, 'won_games': 12, 'draw_games': 4},
    {'reg_number': 13, 'surname': 'Зайцев', 'name': 'Артем', 'patronymic': 'Артемович', 'birth_year': 1991, 'total_games': 29, 'won_games': 17, 'draw_games': 7},
    {'reg_number': 14, 'surname': 'Лебедев', 'name': 'Михаил', 'patronymic': 'Михайлович', 'birth_year': 1984, 'total_games': 33, 'won_games': 20, 'draw_games': 9},
    {'reg_number': 15, 'surname': 'Симонов', 'name': 'Павел', 'patronymic': 'Павлович', 'birth_year': 1977, 'total_games': 31, 'won_games': 18, 'draw_games': 8},
    {'reg_number': 16, 'surname': 'Киселев', 'name': 'Владимир', 'patronymic': 'Владимирович', 'birth_year': 1989, 'total_games': 35, 'won_games': 23, 'draw_games': 7},
    {'reg_number': 17, 'surname': 'Медведев', 'name': 'Денис', 'patronymic': 'Анатольевич', 'birth_year': 1986, 'total_games': 24, 'won_games': 14, 'draw_games': 6},
    {'reg_number': 18, 'surname': 'Белов', 'name': 'Марк', 'patronymic': 'Николаевич', 'birth_year': 1993, 'total_games': 30, 'won_games': 18, 'draw_games': 9},
    {'reg_number': 19, 'surname': 'Горбунов', 'name': 'Александр', 'patronymic': 'Сергеевич', 'birth_year': 1974, 'total_games': 28, 'won_games': 17, 'draw_games': 5},
    {'reg_number': 20, 'surname': 'Соколов', 'name': 'Илья', 'patronymic': 'Игоревич', 'birth_year': 1981, 'total_games': 26, 'won_games': 15, 'draw_games': 7},
    {'reg_number': 21, 'surname': 'Михайлов', 'name': 'Роман', 'patronymic': 'Дмитриевич', 'birth_year': 1978, 'total_games': 32, 'won_games': 20, 'draw_games': 8},
    {'reg_number': 22, 'surname': 'Федоров', 'name': 'Егор', 'patronymic': 'Алексеевич', 'birth_year': 1995, 'total_games': 22, 'won_games': 12, 'draw_games': 6},
    {'reg_number': 23, 'surname': 'Борисов', 'name': 'Никита', 'patronymic': 'Юрьевич', 'birth_year': 1989, 'total_games': 35, 'won_games': 23, 'draw_games': 7},
    {'reg_number': 24, 'surname': 'Воробьев', 'name': 'Степан', 'patronymic': 'Александрович', 'birth_year': 1976, 'total_games': 31, 'won_games': 19, 'draw_games': 6},
    {'reg_number': 25, 'surname': 'Ковалев', 'name': 'Леонид', 'patronymic': 'Михайлович', 'birth_year': 1982, 'total_games': 29, 'won_games': 16, 'draw_games': 8},
    {'reg_number': 26, 'surname': 'Ильин', 'name': 'Антон', 'patronymic': 'Викторович', 'birth_year': 1990, 'total_games': 33, 'won_games': 21, 'draw_games': 9},
    ]
@app.route('/')
def index():
    current_year = 2024
    return render_template('index.html', participants=participants)

@app.route('/older_than_40')
def older_than_40():
    current_year = 2024
    filtered_participants = [p for p in participants if current_year - p['birth_year'] > 40]
    return render_template('older_than_40.html', participants=filtered_participants)


@app.route('/congratulations')
def generate_congratulations():
    sorted_participants = sorted(participants, key=lambda x: x['won_games'], reverse=True)[:3]
    archive_path = "certificates.zip"
    with ZipFile(archive_path, 'w') as zipf:
        for i, participant in enumerate(sorted_participants, start=1):
            filename = f"certificate_{participant['surname']}_{i}.pdf"
            # Предположим, что у вас есть функция generate_certificate для создания PDF
            generate_certificate(f"{participant['surname']} {participant['name']} {participant['patronymic']}", i, filename)
            zipf.write(filename)
            # Удаляем PDF файл после его добавления в архив
            os.remove(filename)
    
    @after_this_request
    def remove_file(response):
        try:
            os.remove(archive_path)
        except Exception as error:
            print("Error removing or closing downloaded file handle", error)
        return response
    
    return send_file(archive_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)